import csv
import io
import os
import sqlite3
from datetime import date
from functools import wraps

from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, Response
)
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATABASE = os.path.join(BASE_DIR, "school.db")
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key-before-deployment")


def get_db():
    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('student', 'teacher')),
            student_number TEXT
        );

        CREATE TABLE IF NOT EXISTS leave_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            start_date TEXT NOT NULL,
            end_date TEXT NOT NULL,
            reason TEXT NOT NULL,
            request_type TEXT NOT NULL CHECK(request_type IN ('Leave', 'Absence Report')),
            status TEXT NOT NULL DEFAULT 'Pending'
                CHECK(status IN ('Pending', 'Approved', 'Rejected')),
            teacher_comment TEXT DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(student_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            attendance_date TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('Present', 'Absent', 'Excused')),
            note TEXT DEFAULT '',
            marked_by INTEGER NOT NULL,
            UNIQUE(student_id, attendance_date),
            FOREIGN KEY(student_id) REFERENCES users(id),
            FOREIGN KEY(marked_by) REFERENCES users(id)
        );
        """)

        # Demo accounts are created only when the database is first initialized.
        demo_users = [
            ("Demo Student", "student", "Student123!", "student", "STU001"),
            ("Demo Teacher", "teacher", "Teacher123!", "teacher", None),
        ]
        for name, username, password, role, student_number in demo_users:
            existing = db.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone()
            if existing is None:
                db.execute(
                    """INSERT INTO users (name, username, password_hash, role, student_number)
                       VALUES (?, ?, ?, ?, ?)""",
                    (name, username, generate_password_hash(password), role, student_number)
                )


def login_required(role=None):
    def decorator(view_function):
        @wraps(view_function)
        def wrapped(*args, **kwargs):
            if "user_id" not in session:
                flash("Please log in to continue.", "warning")
                return redirect(url_for("login"))
            if role and session.get("role") != role:
                flash("You do not have permission to view that page.", "danger")
                return redirect(url_for("dashboard"))
            return view_function(*args, **kwargs)
        return wrapped
    return decorator


@app.route("/")
def home():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return render_template("home.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        student_number = request.form.get("student_number", "").strip()

        if not all([name, username, password, student_number]):
            flash("Please complete every field.", "danger")
            return render_template("register.html")
        if len(password) < 8:
            flash("Password must contain at least 8 characters.", "danger")
            return render_template("register.html")

        try:
            with get_db() as db:
                db.execute(
                    """INSERT INTO users (name, username, password_hash, role, student_number)
                       VALUES (?, ?, ?, 'student', ?)""",
                    (name, username, generate_password_hash(password), student_number)
                )
            flash("Account created. You can now log in.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("That username is already in use. Choose another one.", "danger")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        with get_db() as db:
            user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()

        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["name"] = user["name"]
            session["role"] = user["role"]
            return redirect(url_for("dashboard"))
        flash("Incorrect username or password.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("home"))


@app.route("/dashboard")
@login_required()
def dashboard():
    with get_db() as db:
        if session["role"] == "student":
            requests = db.execute(
                """SELECT * FROM leave_requests WHERE student_id = ?
                   ORDER BY created_at DESC""", (session["user_id"],)
            ).fetchall()
            attendance = db.execute(
                """SELECT * FROM attendance WHERE student_id = ?
                   ORDER BY attendance_date DESC LIMIT 10""", (session["user_id"],)
            ).fetchall()
            counts = {
                "requests": len(requests),
                "pending": sum(r["status"] == "Pending" for r in requests),
                "approved": sum(r["status"] == "Approved" for r in requests),
                "rejected": sum(r["status"] == "Rejected" for r in requests),
            }
            return render_template("student_dashboard.html", requests=requests,
                                   attendance=attendance, counts=counts, today=date.today().isoformat())

        counts = {
            "students": db.execute("SELECT COUNT(*) FROM users WHERE role='student'").fetchone()[0],
            "pending": db.execute("SELECT COUNT(*) FROM leave_requests WHERE status='Pending'").fetchone()[0],
            "approved": db.execute("SELECT COUNT(*) FROM leave_requests WHERE status='Approved'").fetchone()[0],
            "attendance": db.execute("SELECT COUNT(*) FROM attendance").fetchone()[0],
        }
        pending_requests = db.execute(
            """SELECT lr.*, u.name AS student_name, u.student_number
               FROM leave_requests lr JOIN users u ON u.id = lr.student_id
               WHERE lr.status = 'Pending' ORDER BY lr.created_at ASC LIMIT 8"""
        ).fetchall()
        return render_template("teacher_dashboard.html", counts=counts, requests=pending_requests)


@app.route("/apply", methods=["GET", "POST"])
@login_required("student")
def apply_leave():
    if request.method == "POST":
        start_date = request.form.get("start_date", "")
        end_date = request.form.get("end_date", "")
        reason = request.form.get("reason", "").strip()
        request_type = request.form.get("request_type", "Leave")

        try:
            start = date.fromisoformat(start_date)
            end = date.fromisoformat(end_date)
        except ValueError:
            flash("Please select valid dates.", "danger")
            return render_template("apply.html", today=date.today().isoformat())

        if end < start:
            flash("End date cannot be earlier than start date.", "danger")
        elif not reason:
            flash("Please enter a reason.", "danger")
        elif request_type not in ("Leave", "Absence Report"):
            flash("Please select a valid request type.", "danger")
        else:
            with get_db() as db:
                db.execute(
                    """INSERT INTO leave_requests
                       (student_id, start_date, end_date, reason, request_type)
                       VALUES (?, ?, ?, ?, ?)""",
                    (session["user_id"], start_date, end_date, reason, request_type)
                )
            flash("Your request has been submitted.", "success")
            return redirect(url_for("dashboard"))
    return render_template("apply.html", today=date.today().isoformat())


@app.route("/requests")
@login_required("teacher")
def requests_list():
    status = request.args.get("status", "All")
    query = """SELECT lr.*, u.name AS student_name, u.student_number
               FROM leave_requests lr JOIN users u ON u.id = lr.student_id"""
    params = []
    if status in ("Pending", "Approved", "Rejected"):
        query += " WHERE lr.status = ?"
        params.append(status)
    query += " ORDER BY lr.created_at DESC"
    with get_db() as db:
        requests = db.execute(query, params).fetchall()
    return render_template("requests.html", requests=requests, selected_status=status)


@app.route("/requests/<int:request_id>/decision", methods=["POST"])
@login_required("teacher")
def decide_request(request_id):
    status = request.form.get("status")
    comment = request.form.get("teacher_comment", "").strip()
    if status not in ("Approved", "Rejected"):
        flash("Invalid decision.", "danger")
        return redirect(url_for("requests_list"))
    with get_db() as db:
        item = db.execute("SELECT id FROM leave_requests WHERE id = ?", (request_id,)).fetchone()
        if not item:
            flash("Request not found.", "danger")
        else:
            db.execute(
                "UPDATE leave_requests SET status=?, teacher_comment=? WHERE id=?",
                (status, comment, request_id)
            )
            flash(f"Request {status.lower()}.", "success")
    return redirect(url_for("requests_list"))


@app.route("/attendance", methods=["GET", "POST"])
@login_required("teacher")
def attendance_page():
    if request.method == "POST":
        student_id = request.form.get("student_id", type=int)
        attendance_date = request.form.get("attendance_date", "")
        status = request.form.get("status", "")
        note = request.form.get("note", "").strip()
        try:
            date.fromisoformat(attendance_date)
        except ValueError:
            flash("Please select a valid date.", "danger")
            return redirect(url_for("attendance_page"))
        if status not in ("Present", "Absent", "Excused"):
            flash("Please select a valid attendance status.", "danger")
            return redirect(url_for("attendance_page"))
        with get_db() as db:
            student = db.execute("SELECT id FROM users WHERE id=? AND role='student'", (student_id,)).fetchone()
            if not student:
                flash("Please select a valid student.", "danger")
            else:
                db.execute(
                    """INSERT INTO attendance (student_id, attendance_date, status, note, marked_by)
                       VALUES (?, ?, ?, ?, ?)
                       ON CONFLICT(student_id, attendance_date) DO UPDATE SET
                       status=excluded.status, note=excluded.note, marked_by=excluded.marked_by""",
                    (student_id, attendance_date, status, note, session["user_id"])
                )
                flash("Attendance saved.", "success")
        return redirect(url_for("attendance_page"))

    selected_date = request.args.get("date", date.today().isoformat())
    with get_db() as db:
        students = db.execute(
            """SELECT u.id, u.name, u.student_number, a.status, a.note
               FROM users u LEFT JOIN attendance a
               ON a.student_id=u.id AND a.attendance_date=?
               WHERE u.role='student' ORDER BY u.name""", (selected_date,)
        ).fetchall()
        recent = db.execute(
            """SELECT a.*, u.name AS student_name, u.student_number
               FROM attendance a JOIN users u ON u.id=a.student_id
               ORDER BY attendance_date DESC, u.name LIMIT 30"""
        ).fetchall()
    return render_template("attendance.html", students=students, recent=recent,
                           selected_date=selected_date, today=date.today().isoformat())


@app.route("/reports")
@login_required("teacher")
def reports():
    with get_db() as db:
        summary = db.execute(
            """SELECT u.id, u.name, u.student_number,
               SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END) AS present_days,
               SUM(CASE WHEN a.status='Absent' THEN 1 ELSE 0 END) AS absent_days,
               SUM(CASE WHEN a.status='Excused' THEN 1 ELSE 0 END) AS excused_days,
               COUNT(a.id) AS recorded_days
               FROM users u LEFT JOIN attendance a ON a.student_id=u.id
               WHERE u.role='student'
               GROUP BY u.id ORDER BY u.name"""
        ).fetchall()
        request_summary = db.execute(
            """SELECT status, COUNT(*) AS total FROM leave_requests GROUP BY status"""
        ).fetchall()
    return render_template("reports.html", summary=summary, request_summary=request_summary)


@app.route("/reports/download")
@login_required("teacher")
def download_report():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Student Name", "Student Number", "Present Days", "Absent Days",
                     "Excused Days", "Recorded Days", "Attendance Percentage"])
    with get_db() as db:
        rows = db.execute(
            """SELECT u.name, u.student_number,
               SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END) AS present_days,
               SUM(CASE WHEN a.status='Absent' THEN 1 ELSE 0 END) AS absent_days,
               SUM(CASE WHEN a.status='Excused' THEN 1 ELSE 0 END) AS excused_days,
               COUNT(a.id) AS recorded_days
               FROM users u LEFT JOIN attendance a ON a.student_id=u.id
               WHERE u.role='student' GROUP BY u.id ORDER BY u.name"""
        ).fetchall()
    for row in rows:
        recorded = row["recorded_days"] or 0
        present = row["present_days"] or 0
        percentage = round(present * 100 / recorded, 2) if recorded else 0
        writer.writerow([row["name"], row["student_number"], present,
                         row["absent_days"] or 0, row["excused_days"] or 0,
                         recorded, percentage])
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=attendance_report.csv"}
    )


@app.errorhandler(404)
def page_not_found(_error):
    return render_template("error.html", message="The page you requested was not found."), 404


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
