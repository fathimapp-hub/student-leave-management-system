# CampusCare — Digital Student Absence and Leave Management System

A beginner-friendly Flask + SQLite web application for a college mini-project.

## Features

- Student registration and login
- Passwords stored as secure hashes
- Student leave applications and absence reports
- Teacher review, approval/rejection, and comments
- Attendance marking (Present, Absent, Excused)
- Attendance summary and downloadable CSV report
- SQLite database created automatically

## Requirements

- Python 3.10 or newer
- Internet only for the initial Flask installation
- A laptop/desktop is easiest. On Android, use a Python environment that supports Flask.

## Run on Windows

1. Extract this ZIP file.
2. Open Command Prompt in the extracted `student_leave_management_system` folder.
3. Create a virtual environment:

   ```bash
   py -m venv .venv
   .venv\Scripts\activate
   ```

4. Install Flask:

   ```bash
   pip install -r requirements.txt
   ```

5. Start the website:

   ```bash
   python app.py
   ```

6. Open `http://127.0.0.1:5000` in your browser.

## Run on macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Then open `http://127.0.0.1:5000`.

## Demo accounts

- Student username: `student`
- Student password: `Student123!`
- Teacher username: `teacher`
- Teacher password: `Teacher123!`

Use the student registration page to create more student accounts. Teacher accounts are intentionally not self-registerable.

The SQLite database file `school.db` is created in the project folder when the application starts. Demo accounts are inserted when first initialized.

## Try the complete workflow

1. Log in as `student`.
2. Create a leave request or absence report.
3. Log out and log in as `teacher`.
4. Open Requests and approve or reject the request.
5. Open Attendance and mark the student Present, Absent, or Excused for a date.
6. Open Reports and download the CSV report.
7. Log back in as the student to see the request decision and attendance history.

## Important security notes

This is a local educational prototype, not a production-ready school system. Before deployment:
- Set a strong, random `SECRET_KEY` environment variable.
- Turn off Flask debug mode and use a production WSGI server.
- Use HTTPS, backups, appropriate access controls, rate limiting, and CSRF protection.
- Change/remove demo credentials and restrict teacher-account creation to an administrator.
- Follow your institution's privacy and data-retention rules.
